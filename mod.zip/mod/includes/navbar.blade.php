<ul class="nav navbar-nav">

                <!-- User -->
                @if (Auth::guest())
                        <li><a href="login">Login</a></li>
                        <li><a href="register">Create Account</a></li>
                @else

                        <li><a href="#">Mentor</a></li>
                        <li><a href="#">Message</a></li>

                </ul>

                <ul class="nav navbar-nav navbar-right">
                       
                    <li class="dropdown">
                    <a href="#" class="dropdown-toggle user" data-toggle="dropdown">
                        <img src="{{ Auth::user()->getAvatarUrl() }}" width="25" height="25" /> {{ Auth::user()->username }} <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu" role="menu">
                       
                        <li><a href="{{ route('account.dashboard') }}"><i class="fa fa-btn fa-user"></i> My Account</a></li>

                        <li><a href="{{ route('logout') }}"><i class="fa fa-btn fa-sign-out"></i> Logout</a></li>

                          <li><a href="#"><i class="fa fa-btn fa-sign-out"></i> Settings</a></li>
                    </ul>
                </li>
                @endif
            </ul>