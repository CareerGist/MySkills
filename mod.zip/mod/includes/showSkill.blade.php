   

    <div class="form-group{{ $errors->has('category') ? ' has-error' : '' }}">
      <label for="category" class="col-sm-2 control-label">Category</label>
        <div class="col-sm-8">
          <select class="form-control" id="category" name="category">
            <option value="">Please select a category</option>
              @foreach($category as $item)
                  <option value="{{$item->category_id}}">{{$item->category}}</option>
              @endforeach
            </select>
              @if ($errors->has('Category'))
                        <span class="help-block">{{ $errors->first('Category') }}</span>
               @endif
        </div> 
    </div>

    </br>
              <div class="form-group{{ $errors->has('skill') ? ' has-error' : '' }}">
              <label for="skill" class="col-sm-2 control-label">Skill</label>
              <div class="col-sm-8">
              <select name="skill" id="skill" class="form-control">    
               <option>Please choose a category first</option>
              </select>
               @if ($errors->has('skill'))
                        <span class="help-block">{{ $errors->first('skill') }}</span>
                    @endif 
              </div>
            </div>

     



<script type="text/javascript">
       $(document).ready(function($){
            $('#category').change(function(){
                $.get("{{ url('/dropdown')}}", 
                    { option: $(this).val() },
                        function(data) {
                            $('#skill').empty(); 
                                $.each(data, function(key, element) {
                      $('#skill').append("<option value='" + element.skill_id +"'>" + element.skill + "</option>");
                    });
                });
           });
            
         });

    </script>