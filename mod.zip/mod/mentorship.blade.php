@extends('layouts.master')
@section('clrm', 'show-sidebar sidebar-l2')
@section('title', 'User Profile Page')

@section('mnav')

<div class="container-fluid">


@endsection

@section('navb')
@include('includes.navbar')

        </div>
        <!-- /.navbar-collapse -->

      </div>
    </div>
@endsection

@section('content')
@section('navh', '<a href="#sidebar-menu" data-toggle="sidebar-menu" class="toggle pull-left visible-xs"><i class="fa fa-ellipsis-v"></i></a>')
<div class="sidebar right sidebar-size-2 sidebar-offset-0 sidebar-visible-desktop sidebar-visible-mobile sidebar-skin-dark" id="sidebar-menu">
      <div data-scrollable>
        <h4 class="category"><i class="fa fa-fw fa-folder-open"></i> Profile Pages</h4>
        <div class="sidebar-block">
          <ul class="list-group list-group-menu">
            <li class="list-group-item active"><a href="index.html"><span class="badge pull-right"> </span> Skills Feed </a></li>
            <li class="list-group-item"><a href="index.html"><span class="badge pull-right"> </span> Mentors Feed</a></li>
            <li class="list-group-item"><a href="index.html"><span class="badge pull-right"> </span> People with similar Skills</a></li>
            <li class="list-group-item"><a href="index.html"><span class="badge pull-right"> </span> Jobs relating to your skills</a></li>
            <li class="list-group-item"><a href="index.html"><span class="badge pull-right"> </span> Ask a question</a></li>
            <li class="list-group-item"><a href="index.html"><span class="badge pull-right"> </span> Upload CV</a></li>
            <li class="list-group-item"><a href="index.html"><span class="badge pull-right"> </span> Followers</a></li>
          </ul>
        </div>

        <!-- <h4 class="category"><i class="fa fa-fw fa-eye"></i> View</h4>
        <div class="sidebar-block">
          <div class="form-group">
            <select class="selectpicker">
              <option>List</option>
              <option>Grid</option>
            </select>
          </div>
        </div>
        <h4 class="category"><i class="fa fa-fw fa-dollar"></i> Price</h4>
        <div class="sidebar-block">
          <div class="form-group input-group">
            <div class="row margin-none">
              <div class="col-xs-6 padding-none">
                <input class="form-control" type="text" placeholder="Min .." />
              </div>
              <div class="col-xs-6 padding-none">
                <input class="form-control" type="text" placeholder="Max .." />
              </div>
            </div>
            <div class="input-group-btn">
              <button type="button" class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>
          </div>
        </div> -->
      </div>
    </div>

    <div class="st-pusher" id="content">

      <!-- sidebar effects INSIDE of st-pusher: -->
      <!-- st-effect-3, st-effect-6, st-effect-7, st-effect-8, st-effect-14 -->

      <!-- this is the wrapper for the content -->
      <div class="st-content">

        <!-- extra div for emulating position:fixed of the menu -->
        <div class="st-content-inner">

          <div class="container-fluid ctc">

             
             <div class="timeline row" data-toggle="isotope">  
               <div class="col-xs-12 col-md-12 col-lg-12 item">
                  <div class="timeline-block">
                    <div class="panel panel-default share clearfix-xs">
                     <div class="panel-heading panel-heading-gray title">
                      What&acute;s new
                    </div>
                    <div class="panel-body">
                      <textarea name="status" class="form-control share-text" rows="3" placeholder="Share a Post with your mentees..."></textarea>
                    </div>
                    <div class="panel-footer share-buttons">
                      <a href="#"><i class="fa fa-map-marker"></i></a>
                      <a href="#"><i class="fa fa-photo"></i></a>
                      <a href="#"><i class="fa fa-video-camera"></i></a>
                      <button type="submit" class="btn btn-primary btn-xs pull-right display-none" href="#">Post</button>
                    </div>
                  </div>
                </div>
              </div>


              <div class="col-xs-12 col-md-12 col-lg-12 item">
                <div class="timeline-block">
                  <div class="panel panel-default">

                    <div class="panel-heading">
                      <div class="media">
                        <div class="media-left">
                          <a href="">
                            <img src="images/people/50/guy-2.jpg" class="media-object">
                          </a>
                        </div>
                        <div class="media-body">
                          <a href="#" class="pull-right text-muted"><i class="icon-reply-all-fill fa fa-2x "></i></a>

                          <a href="">Demola Tosin</a>

                          <span>on 15th September, 2016</span>
                        </div>
                      </div>
                    </div>

                    <div class="panel-body">
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad blanditiis perspiciatis praesentium quaerat repudiandae soluta? Cum doloribus esse et eum facilis impedit officiis omnis optio, placeat, quia quo reprehenderit sunt velit?
                        Asperiores cumque deserunt eveniet hic reprehenderit sit, ut voluptatum?</p>
                    </div>
                    <div class="panel-footer share-buttons">
                      <a href="#"><i class="fa fa-comments"></i></a>
                      <a href="#"><i class="fa fa-share"></i></a>
          
                      <button type="submit" class="btn btn-primary btn-xs pull-right display-none" href="#">Post</button>
                    </div>
                    <div class="view-all-comments">
                      <a href="#">
                        <i class="fa fa-comments-o"></i> View all
                      </a>
                      <span>10 comments</span>

                    </div>
                    <ul class="comments">
                      <li class="media">
                        <div class="media-left">
                          <a href="">
                            <img src="images/people/50/guy-5.jpg" class="media-object">
                          </a>
                        </div>
                        <div class="media-body">
                          <div class="pull-right dropdown" data-show-hover="li">
                            <a href="#" data-toggle="dropdown" class="toggle-button">
                              <i class="fa fa-pencil"></i>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                              <li><a href="#">Edit</a></li>
                              <li><a href="#">Delete</a></li>
                            </ul>
                          </div>
                          <a href="" class="comment-author pull-left">Bill D.</a>
                          <span>Hi Demola, Nice One</span>
                          <div class="comment-date">21st September</div>
                        </div>
                      </li>
                      <li class="media">
                        <div class="media-left">
                          <a href="">
                            <img src="images/people/50/woman-5.jpg" class="media-object">
                          </a>
                        </div>
                        <div class="media-body">
                          <div class="pull-right dropdown" data-show-hover="li">
                            <a href="#" data-toggle="dropdown" class="toggle-button">
                              <i class="fa fa-pencil"></i>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                              <li><a href="#">Edit</a></li>
                              <li><a href="#">Delete</a></li>
                            </ul>
                          </div>
                          <a href="" class="comment-author pull-left">Mary</a>
                          <span>Thanks Demola</span>
                          <div class="comment-date">2 days</div>
                        </div>
                      </li>
                      <li class="media">
                        <div class="media-left">
                          <a href="">
                            <img src="images/people/50/guy-5.jpg" class="media-object">
                          </a>
                        </div>
                        <div class="media-body">
                          <div class="pull-right dropdown" data-show-hover="li">
                            <a href="#" data-toggle="dropdown" class="toggle-button">
                              <i class="fa fa-pencil"></i>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                              <li><a href="#">Edit</a></li>
                              <li><a href="#">Delete</a></li>
                            </ul>
                          </div>
                          <a href="" class="comment-author pull-left">Bill D.</a>
                          <span>Wow!</span>
                          <div class="comment-date">14 min</div>
                        </div>
                      </li>
                      <li class="comment-form">
                        <div class="input-group">

                          <span class="input-group-btn">
                   <a href="" class="btn btn-default"><i class="fa fa-photo"></i></a>
                </span>

                          <input type="text" class="form-control" />

                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

            </div>
                  


           






      </div>

     </div>
        <!-- /st-content-inner -->

      </div>
      <!-- /st-content -->

   </div>




@endsection