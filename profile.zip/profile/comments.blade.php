
<h4>Public Comments</h4>
            <form id="cform">
              <div class="form-group input-group">
                <input id="comment" type="text" class="form-control" placeholder="Your comment ..">
                <span class="input-group-btn">
            <button value="submit" id="comSubmit"class="btn btn-primary" type="button"><i class="fa fa-plus"></i></button>
        </span>
              </div>
            </form>
             <div id="commentRef" class="container-fluid">
            @forelse($comments as $index => $comment )
            <section class="panel panel-default">
              <div class="panel-body">
                <div class="media">
                  <a class="media-left" href="">
                    <img class="media-object" src="{{asset('/images/people/50/guy-2.jpg')}}" alt="people" />
                  </a>
                  <div class="media-body">
                    <small class="text-grey-400 pull-right">2 minutes ago</small>
                    <h5 class="media-heading margin-v-5"><a href="{{ route('others.profile', array('username' => $writers[$index]->username)) }}">{{$writers[$index]->fullname or $writers[$index]->username}}</a></h5>
                    <p class="margin-none">{{$comment->comment}}</p>
                  </div>
                </div>
              </div>
            </section>
            @empty
            Be the first to write a comment...
            @endforelse

        </div>
                       
          
           