

            
            @forelse($comments as $index => $comment )
            <section class="panel panel-default">
              <div class="panel-body">
                <div class="media">
                  <a class="media-left" href="">
                    <img class="media-object" src="{{asset('/images/people/50/guy-2.jpg')}}" alt="people" />
                  </a>
                  <div class="media-body">
                    <small class="text-grey-400 pull-right">2 minutes ago</small>
                    <h5 class="media-heading margin-v-5"><a href="{{ route('others.profile', array('username' => $writers[$index]->username)) }}">{{$writers[$index]->fullname or $writers[$index]->username}}</a></h5>
                    <p class="margin-none">{{$comment->comment}}</p>
                  </div>
                </div>
              </div>
            </section>
            @empty
            Be the first to write a comment...
            @endforelse
                
