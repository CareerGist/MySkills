            @can('owner', $user)
                    @include('skills.skillsControlPanel')      

            <div class="page-header">
              <h1 class="h3 pull-left margin-none">Your Skillset</h1>
              <div class="pull-right">
                <div class="btn-group">
                  <!--<a class="btn bg-gray-dark" href="library.html"><i class="fa fa-list"></i></a>
                  <a class="btn btn-default" href="library-grid.html"><i class="fa fa-th"></i></a> -->
                </div>
              </div>
              <div class="clearfix"></div>
            </div>
             @endcan

             @cannot('owner', $user)
              @include('skills.othersSkillsControlPanel')
                  
            <div class="page-header">
              <h1 class="h3 pull-left margin-none">{{$user->fullname or $user->username}}'s Skillset</h1>
              <div class="pull-right">
                <div class="btn-group">
                  <!--<a class="btn bg-gray-dark" href="library.html"><i class="fa fa-list"></i></a>
                  <a class="btn btn-default" href="library-grid.html"><i class="fa fa-th"></i></a> -->
                </div>
              </div>
              <div class="clearfix"></div>
            </div>
              @endcannot