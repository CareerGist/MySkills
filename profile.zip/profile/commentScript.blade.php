					 <script>                 
                      $(document).ready(function($){                   
                              
                              
                              var submit = $('#comSubmit');
                              var form = $('#cform');

                               
                                    
                          $('body').on('click','#comSubmit',function(evt){    
                             $.ajaxSetup({
                             headers: {
                              'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                                  }
                                })

                            user_id = {{$user->user_id}};
                            viewer_id = {{$viewer}};
                            comment = $("#comment").val();
                             
                             url = 'http://localhost/myskills/public/submit/profile/comment';
                             
                              $.ajax({
                                          type: "POST",
                                           url: url,
                                          data: {user_id:user_id, viewer_id:viewer_id, comment:comment},
                                           cache: false,
                                      beforeSend: function(){
                                        // change submit button value text and disabled it
                                        
                                        submit.css('background-color', 'grey');
                                      },
                                          success: function (data) {
                                            
                                          submit.css('background-color', '#16ae9f');
                                            $('#cform')[0].reset();

                                               @can('owner', $user)
                              	 				 $("#commentRef").load("{{route('ajax.profile.comment')}}");
                             					 @endcannot
                              					@cannot('owner', $user)
                                				$("#commentRef").load("{{ route('others.ajax.profile.comment', array('user' => $user->user_id))}}");
                             					 @endcannot
                                       
                                       		   },
                                        		  error: function (data) {
                                           		   console.log('Error:', data);
                                          }
                                      });
                            
                              evt.preventDefault();
                  
                          
                          });
                        })
                      </script> 
