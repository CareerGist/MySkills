@extends('layouts.master')
@section('clrm', 'show-sidebar sidebar-l2')
@section('title', 'Profile')

@section('navb')
@include('includes.navbar')

        </div>
        <!-- /.navbar-collapse -->

      </div>
    </div>
@endsection

@section('content')
@section('navh', '<a href="#sidebar-menu" data-toggle="sidebar-menu" class="toggle pull-left visible-xs"><i class="fa fa-ellipsis-v"></i></a>')
@include('includes.sidebar')

<div class="st-pusher" id="content">

      <!-- sidebar effects INSIDE of st-pusher: -->
      <!-- st-effect-3, st-effect-6, st-effect-7, st-effect-8, st-effect-14 -->

      <!-- this is the wrapper for the content -->
      <div class="st-content">

        <!-- extra div for emulating position:fixed of the menu -->
        <div class="st-content-inner">
        
              <div id="loading" style="display:none;position:absolute;top:90%;left:50%;"><img src="{{asset('/images/ajax-loader.gif')}}"></div>  
          
          <div class="container-fluid">           
           @include('profile.profilePanel')  
          </div>
          <div id="ajaxRef" class="container-fluid">       
           @include('skills.showSkills')                
           @include('profile.videoCV')          
           @include('mentors.mentor_include')
          </div>
         
          @include('profile.comments')
        
          @include('profile.commentScript')
        <!-- /st-content-inner -->
        
      </div>
      <!-- /st-content -->

    </div>
 </div>

     <script>
            var socket = io.connect(':8890');
                 // optionally use io('http://localhost:3000');
            socket.on('user.profile.{{$user->user_id}}', function(data) {
                console.log(data);
            });
            socket.on('error', console.error.bind(console));
            socket.on('message', console.log.bind(console));

            function addMessage(message) {
                var text = document.createTextNode(message),
                    el = document.createElement('li'),
                    messages = document.getElementById('messages');

                el.appendChild(text);
                messages.appendChild(el);
            }
        </script>
 

 @endsection