
<div class="panel panel-default">
                  <div class="panel-heading">
                    <h4 class="panel-title"> Video Profile</h4>
                  </div>
                  <div class="panel-body">
                 <video width="320" height="240" controls>
                      <source src="{{asset('/images/HTML5 Video.mp4')}}" type="video/mp4">
                     
                    Your browser does not support the video tag.
                </video>
               </div>
                </div>
                