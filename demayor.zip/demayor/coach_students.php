<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class coach_students extends Model
{
    //


    public function getCoach(){
        return $this->belongsTo('App\coach','coach_id');
    }

}
