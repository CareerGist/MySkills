<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class coach extends Model
{
    //

    public function coachStudents(){
        return $this->hasMany('App\coach_sudents','coach_id');
    }
}
