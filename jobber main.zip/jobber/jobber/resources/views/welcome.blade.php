@extends('layouts.master')

@section('content')
    <div class="main-container">
         <h1>HOME</h1>
    </div>
@stop