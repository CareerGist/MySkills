<div class="st-container">
<div class="navbar navbar-main navbar-primary navbar-fixed-top" role="navigation">
      <div class="container">

        <div class="navbar-header">
        @yield('navh')
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-nav">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        <!-- <a href="#sidebar-chat" data-toggle="sidebar-menu" class="toggle pull-right visible-xs"><i class="fa fa-comments"></i></a>-->
          <a class="navbar-brand" href="/">Career Gist</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="main-nav">
          <!--<ul class="nav navbar-nav">
            <li><a href="tutors.html">Tutors</a></li>
            <li><a href="survey.html">Survey</a></li>
            <li><a href="library-grid.html">Library</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">UI <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="essential-buttons.html"><i class="fa fa-th"></i> Buttons</a></li>
                <li><a href="essential-icons.html"><i class="fa fa-paint-brush"></i> Icons</a></li>
                <li><a href="essential-progress.html"><i class="fa fa-tasks"></i> Progress</a></li>
                <li><a href="essential-grid.html"><i class="fa fa-columns"></i> Grid</a></li>
                <li><a href="essential-forms.html"><i class="fa fa-sliders"></i> Forms</a></li>
                <li><a href="essential-tables.html"><i class="fa fa-table"></i> Tables</a></li>
                <li><a href="essential-tabs.html"><i class="fa fa-circle-o"></i> Tabs</a></li>
              </ul>
            </li>
            <li><a href="../../../index.html">Themes</a></li>
            <li data-toggle="tooltip" data-placement="bottom" title="A few Color Examples. Download includes CSS Files for all color examples & the tools to Generate any Color combination. This Color-Switcher is for previewing purposes only.">
              <ul class="skins">

                <li><span data-file="app/app" data-skin="default" style="background: #16ae9f "></span></li>

                <li><span data-file="skin-orange" data-skin="orange" style="background: #e74c3c "></span></li>

                <li><span data-file="skin-blue" data-skin="blue" style="background: #4687ce "></span></li>

                <li><span data-file="skin-purple" data-skin="purple" style="background: #af86b9 "></span></li>

                <li><span data-file="skin-brown" data-skin="brown" style="background: #c3a961 "></span></li> 

              </ul>
            </li>
          </ul> -->
          <form class="navbar-form nv navbar-left" role="search">
        <div class="form-group input-group">
          <input type="text" class="form-control" placeholder="Search Skills">
          <div class="input-group-btn">
            <button type="button" class="btn btn-default"><i class="fa fa-search"></i></button>
          </div>
        </div>

        </form>
      
